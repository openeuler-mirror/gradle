package org.gradle.test.sub

class SubGroovyClass {
}
