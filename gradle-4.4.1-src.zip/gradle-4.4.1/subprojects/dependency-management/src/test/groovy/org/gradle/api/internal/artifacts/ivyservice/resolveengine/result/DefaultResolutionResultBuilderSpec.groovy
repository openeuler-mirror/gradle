/*
 * Copyright 2012 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.api.internal.artifacts.ivyservice.resolveengine.result

import org.gradle.api.artifacts.ModuleVersionIdentifier
import org.gradle.api.artifacts.component.ComponentIdentifier
import org.gradle.api.artifacts.component.ComponentSelector
import org.gradle.api.artifacts.result.ComponentSelectionReason
import org.gradle.api.internal.artifacts.dependencies.DefaultImmutableVersionConstraint
import org.gradle.api.internal.artifacts.dependencies.DefaultMutableVersionConstraint
import org.gradle.api.internal.artifacts.ivyservice.resolveengine.graph.ComponentResult
import org.gradle.api.internal.artifacts.ivyservice.resolveengine.graph.DependencyResult
import org.gradle.internal.component.external.model.DefaultModuleComponentIdentifier
import org.gradle.internal.component.external.model.DefaultModuleComponentSelector
import org.gradle.internal.resolve.ModuleVersionResolveException
import spock.lang.Specification

import static org.gradle.api.internal.artifacts.DefaultModuleVersionIdentifier.newId
import static org.gradle.api.internal.artifacts.DefaultModuleVersionSelector.newSelector
import static org.gradle.api.internal.artifacts.ivyservice.resolveengine.result.ResolutionResultPrinter.printGraph
import static org.gradle.util.CollectionUtils.first

class DefaultResolutionResultBuilderSpec extends Specification {

    def builder = new DefaultResolutionResultBuilder()

    def "builds basic graph"() {
        given:
        node("root")
        node("mid1")
        node("mid2")
        node("leaf1")
        node("leaf2")
        node("leaf3")
        node("leaf4")

        resolvedConf("root", [dep("mid1"), dep("mid2")])

        resolvedConf("mid1", [dep("leaf1"), dep("leaf2")])
        resolvedConf("mid2", [dep("leaf3"), dep("leaf4")])

        resolvedConf("leaf1", [])
        resolvedConf("leaf2", [])
        resolvedConf("leaf3", [])
        resolvedConf("leaf4", [])

        when:
        def result = builder.complete(id("root"))

        then:
        printGraph(result.root) == """x:root:1
  x:mid1:1 [root]
    x:leaf1:1 [mid1]
    x:leaf2:1 [mid1]
  x:mid2:1 [root]
    x:leaf3:1 [mid2]
    x:leaf4:1 [mid2]
"""
    }

    def "graph with multiple dependents"() {
        given:
        node("a")
        node("b1")
        node("b2")
        node("b3")

        resolvedConf("a", [dep("b1"), dep("b2"), dep("b3")])

        resolvedConf("b1", [dep("b2"), dep("b3")])
        resolvedConf("b2", [dep("b3")])
        resolvedConf("b3", [])

        when:
        def result = builder.complete(id("a"))

        then:
        printGraph(result.root) == """x:a:1
  x:b1:1 [a]
    x:b2:1 [a,b1]
      x:b3:1 [a,b1,b2]
  x:b2:1 [a,b1]
    x:b3:1 [a,b1,b2]
  x:b3:1 [a,b1,b2]
"""
    }

    def "builds graph with cycles"() {
        given:
        node("a")
        node("b")
        node("c")
        resolvedConf("a", [dep("b")])
        resolvedConf("b", [dep("c")])
        resolvedConf("c", [dep("a")])

        when:
        def result = builder.complete(id("a"))

        then:
        printGraph(result.root) == """x:a:1
  x:b:1 [a]
    x:c:1 [b]
      x:a:1 [c]
"""
    }

    def "includes selection reason"() {
        given:
        node("a")
        node("b", VersionSelectionReasons.FORCED)
        node("c", VersionSelectionReasons.CONFLICT_RESOLUTION)
        node("d")
        resolvedConf("a", [dep("b"), dep("c"), dep("d", new RuntimeException("Boo!"))])
        resolvedConf("b", [])
        resolvedConf("c", [])
        resolvedConf("d", [])

        when:
        def deps = builder.complete(id("a")).root.dependencies

        then:
        def b = deps.find { it.selected.id.module == 'b' }
        def c = deps.find { it.selected.id.module == 'c' }

        b.selected.selectionReason.forced
        c.selected.selectionReason.conflictResolution
    }

    def "links dependents correctly"() {
        given:
        node("a")
        node("b")
        node("c")
        resolvedConf("a", [dep("b")])
        resolvedConf("b", [dep("c")])
        resolvedConf("c", [dep("a")])

        when:
        def a = builder.complete(id("a")).root

        then:
        def b  = first(a.dependencies).selected
        def c  = first(b.dependencies).selected
        def a2 = first(c.dependencies).selected

        a2.is(a)

        first(b.dependents).is(first(a.dependencies))
        first(c.dependents).is(first(b.dependencies))
        first(a.dependents).is(first(c.dependencies))

        first(b.dependents).from.is(a)
        first(c.dependents).from.is(b)
        first(a.dependents).from.is(c)
    }

    def "accumulates and avoids duplicate dependencies"() {
        given:
        node("root")
        node("mid1")
        node("leaf1")
        node("leaf2")

        resolvedConf("root", [dep("mid1")])

        resolvedConf("mid1", [dep("leaf1")])
        resolvedConf("mid1", [dep("leaf1")]) //dupe
        resolvedConf("mid1", [dep("leaf2")])

        resolvedConf("leaf1", [])
        resolvedConf("leaf2", [])

        when:
        def result = builder.complete(id("root"))

        then:
        printGraph(result.root) == """x:root:1
  x:mid1:1 [root]
    x:leaf1:1 [mid1]
    x:leaf2:1 [mid1]
"""
    }

    def "accumulates and avoids duplicate unresolved dependencies"() {
        given:
        node("root")
        node("mid1")
        node("leaf1")
        node("leaf2")
        resolvedConf("root", [dep("mid1")])

        resolvedConf("mid1", [dep("leaf1", new RuntimeException("foo!"))])
        resolvedConf("mid1", [dep("leaf1", new RuntimeException("bar!"))]) //dupe
        resolvedConf("mid1", [dep("leaf2", new RuntimeException("baz!"))])

        when:
        def result = builder.complete(id("root"))

        then:
        def mid1 = first(result.root.dependencies)
        mid1.selected.dependencies.size() == 2
        mid1.selected.dependencies*.requested.module == ['leaf1', 'leaf2']
    }

    def "graph includes unresolved deps"() {
        given:
        node("a")
        node("b")
        node("c")
        resolvedConf("a", [dep("b"), dep("c"), dep("U", new RuntimeException("unresolved!"))])
        resolvedConf("b", [])
        resolvedConf("c", [])

        when:
        def result = builder.complete(id("a"))

        then:
        printGraph(result.root) == """x:a:1
  x:b:1 [a]
  x:c:1 [a]
  x:U:1 -> x:U:1 - Could not resolve x:U:1.
"""
    }

    private void node(String module, ComponentSelectionReason reason = VersionSelectionReasons.REQUESTED) {
        DummyModuleVersionSelection moduleVersion = comp(module, reason)
        builder.visitComponent(moduleVersion)
    }

    private DummyModuleVersionSelection comp(String module, ComponentSelectionReason reason = VersionSelectionReasons.REQUESTED) {
        def moduleVersion = new DummyModuleVersionSelection(resultId: id(module), moduleVersion: newId("x", module, "1"), selectionReason: reason, componentId: new DefaultModuleComponentIdentifier("x", module, "1"))
        moduleVersion
    }

    private void resolvedConf(String module, List<DependencyResult> deps) {
        builder.visitOutgoingEdges(id(module), deps)
    }

    private DependencyResult dep(String requested, Exception failure = null, String selected = requested) {
        def selector = new DefaultModuleComponentSelector("x", requested, DefaultImmutableVersionConstraint.of("1"))
        def moduleVersionSelector = newSelector("x", requested, new DefaultMutableVersionConstraint("1"))
        failure = failure == null ? null : new ModuleVersionResolveException(moduleVersionSelector, failure)
        new DummyInternalDependencyResult(requested: selector, selected: id(selected), failure: failure)
    }

    private Long id(String module) {
        return module.hashCode()
    }

    class DummyModuleVersionSelection implements ComponentResult {
        Long resultId
        ModuleVersionIdentifier moduleVersion
        ComponentSelectionReason selectionReason
        ComponentIdentifier componentId
    }

    class DummyInternalDependencyResult implements DependencyResult {
        ComponentSelector requested
        Long selected
        ModuleVersionResolveException failure
        ComponentSelectionReason reason
    }
}
